insert into student (id , name , address, email) values (101 , 'Josh' , 'Bangalore', 'jos@gmail.com');
insert into student (id , name , address, email) values (102 , 'sam' , 'Hyderabad' , 'sam@gmail.com');
insert into student (id , name , address, email) values (103 , 'gaana' , 'chennai' , 'gana@gmail.com');
